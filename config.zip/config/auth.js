
module.exports = {

	"googleAuth" : {
		"clientID"     : "672579006825-u16oiouu0oae8dr6dfd6iodlae2tohhu.apps.googleusercontent.com",
		"clientSecret" : "PPkoRRSqrjMbZTGqBBaH1Ezf",
		"callbackURL"  : (process.env.OPENSHIFT_NODEJS_IP) ? "http://lsmsasgo.com/auth/google/callback" : "http://localhost:3000/auth/google/callback"
	},

	"mailer" : {
		"auth" : {
			"user" : "sgo@lsmsa.edu",
			"pass" : "wahhwahh"
		},
		"defaultFromAddress" : "SGO Website <sgo@lsmsa.edu>"
	},

	"cookie" : {
		"secret" : "23487hsdfjn2348akjds"
	}

}
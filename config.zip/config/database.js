module.exports = {

	"connection" : {
        host     : process.env.OPENSHIFT_MYSQL_DB_HOST,
        user     : process.env.OPENSHIFT_MYSQL_DB_USERNAME,
        password : process.env.OPENSHIFT_MYSQL_DB_PASSWORD,
        port     : process.env.OPENSHIFT_MYSQL_DB_PORT,
        database : 'lsmsa'
	},

	"connection_local" : {
		"host"     : "localhost",
		"user"     : "root",
		"password" : ""
	},

	"database"       : "sgo",
	"tb_users"       : "users",
	"tb_issues"      : "issues"

}